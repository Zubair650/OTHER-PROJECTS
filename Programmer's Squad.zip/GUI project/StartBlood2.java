public class StartBlood2 
{
	public static void main(String [] args)
	{
		try{
			
		Blood7 f1 = new Blood7();
		f1.show();
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		//f1.setVisible(true);
	}
}